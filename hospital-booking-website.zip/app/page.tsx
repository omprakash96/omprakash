import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { PatientCareSection } from "@/components/patient-care-section"
import { ServicesSection } from "@/components/services-section"
import { BookingForm } from "@/components/booking-form"
import { RegistrationForm } from "@/components/registration-form"
import { Footer } from "@/components/footer"
import { Toaster } from "@/components/ui/sonner"

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <HeroSection />
        <PatientCareSection />
        <ServicesSection />
        <BookingForm />
        <RegistrationForm />
      </main>
      <Footer />
      <Toaster position="top-center" />
    </div>
  )
}
