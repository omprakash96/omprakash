"use client"

import Link from "next/link"
import { useState } from "react"
import { Menu, X, Phone, Mail, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-card border-b border-border">
      {/* Top bar */}
      <div className="bg-primary text-primary-foreground py-2 px-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2 text-sm">
          <div className="flex items-center gap-6">
            <a href="tel:+919534311724" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <Phone className="h-4 w-4" />
              <span>+91 9534311724</span>
            </a>
            <a href="mailto:papuyadav780@gmail.com" className="hidden sm:flex items-center gap-2 hover:opacity-80 transition-opacity">
              <Mail className="h-4 w-4" />
              <span>papuyadav780@gmail.com</span>
            </a>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            <span>24/7 Emergency Services</span>
          </div>
        </div>
      </div>

      {/* Main navigation */}
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg">HNC</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">HNC प्राकृतिक उपचार केंद्र</h1>
              <p className="text-xs text-muted-foreground">आपका स्वास्थ्य, हमारी प्राथमिकता</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <Link href="/" className="text-foreground hover:text-primary transition-colors font-medium">
              Home
            </Link>
            <Link href="#services" className="text-foreground hover:text-primary transition-colors font-medium">
              Services
            </Link>
            <Link href="#booking" className="text-foreground hover:text-primary transition-colors font-medium">
              Book Appointment
            </Link>
            <Link href="#registration" className="text-foreground hover:text-primary transition-colors font-medium">
              Patient Registration
            </Link>
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <Button variant="outline" asChild>
              <Link href="#registration">Register</Link>
            </Button>
            <Button asChild>
              <Link href="#booking">Book Now</Link>
            </Button>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 text-foreground hover:bg-secondary rounded-lg transition-colors"
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 py-4 border-t border-border flex flex-col gap-4">
            <Link href="/" className="text-foreground hover:text-primary transition-colors font-medium">
              Home
            </Link>
            <Link href="#services" className="text-foreground hover:text-primary transition-colors font-medium">
              Services
            </Link>
            <Link href="#booking" className="text-foreground hover:text-primary transition-colors font-medium">
              Book Appointment
            </Link>
            <Link href="#registration" className="text-foreground hover:text-primary transition-colors font-medium">
              Patient Registration
            </Link>
            <div className="flex flex-col gap-2 pt-4 border-t border-border">
              <Button variant="outline" asChild className="w-full">
                <Link href="#registration">Register</Link>
              </Button>
              <Button asChild className="w-full">
                <Link href="#booking">Book Now</Link>
              </Button>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}
