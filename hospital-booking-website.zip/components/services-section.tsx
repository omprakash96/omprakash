import { Heart, Brain, Bone, Baby, Eye, Stethoscope } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const services = [
  {
    icon: Heart,
    title: "Cardiology",
    description: "Comprehensive heart care with advanced diagnostic and treatment facilities.",
  },
  {
    icon: Brain,
    title: "Neurology",
    description: "Expert care for brain and nervous system disorders.",
  },
  {
    icon: Bone,
    title: "Orthopedics",
    description: "Specialized bone and joint care with modern surgical techniques.",
  },
  {
    icon: Baby,
    title: "Pediatrics",
    description: "Dedicated healthcare services for infants and children.",
  },
  {
    icon: Eye,
    title: "Ophthalmology",
    description: "Complete eye care from routine checkups to complex surgeries.",
  },
  {
    icon: Stethoscope,
    title: "General Medicine",
    description: "Primary healthcare and preventive medicine services.",
  },
]

export function ServicesSection() {
  return (
    <section id="services" className="py-16 md:py-24 bg-card">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">Our Departments</h2>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto text-pretty">
            Choose from our wide range of medical specialties and book your appointment with the right department.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <Card key={service.title} className="group hover:shadow-lg transition-all duration-300 hover:border-primary/50">
              <CardContent className="p-6">
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary group-hover:scale-110 transition-all duration-300">
                  <service.icon className="h-7 w-7 text-primary group-hover:text-primary-foreground transition-colors" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-2">{service.title}</h3>
                <p className="text-muted-foreground text-pretty">{service.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
