import Link from "next/link"
import { Phone, Mail, MapPin, Clock, Facebook, Twitter, Instagram, Linkedin } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-foreground text-background">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">HNC</span>
              </div>
              <div>
                <h3 className="font-bold">HNC प्राकृतिक उपचार केंद्र</h3>
              </div>
            </div>
            <p className="text-background/70 text-sm leading-relaxed">
              प्राकृतिक उपचार और बेहतर स्वास्थ्य सेवाओं के साथ आपकी सेवा में समर्पित। आपका स्वास्थ्य, हमारी प्राथमिकता।
            </p>
            <div className="flex gap-3 mt-4">
              <a href="#" className="w-9 h-9 rounded-full bg-background/10 hover:bg-primary flex items-center justify-center transition-colors" aria-label="Facebook">
                <Facebook className="h-4 w-4" />
              </a>
              <a href="#" className="w-9 h-9 rounded-full bg-background/10 hover:bg-primary flex items-center justify-center transition-colors" aria-label="Twitter">
                <Twitter className="h-4 w-4" />
              </a>
              <a href="#" className="w-9 h-9 rounded-full bg-background/10 hover:bg-primary flex items-center justify-center transition-colors" aria-label="Instagram">
                <Instagram className="h-4 w-4" />
              </a>
              <a href="#" className="w-9 h-9 rounded-full bg-background/10 hover:bg-primary flex items-center justify-center transition-colors" aria-label="LinkedIn">
                <Linkedin className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#services" className="text-background/70 hover:text-primary transition-colors text-sm">
                  Our Services
                </Link>
              </li>
              <li>
                <Link href="#booking" className="text-background/70 hover:text-primary transition-colors text-sm">
                  Book Appointment
                </Link>
              </li>
              <li>
                <Link href="#registration" className="text-background/70 hover:text-primary transition-colors text-sm">
                  Patient Registration
                </Link>
              </li>
              <li>
                <Link href="#" className="text-background/70 hover:text-primary transition-colors text-sm">
                  Find a Doctor
                </Link>
              </li>
              <li>
                <Link href="#" className="text-background/70 hover:text-primary transition-colors text-sm">
                  Health Packages
                </Link>
              </li>
            </ul>
          </div>

          {/* Departments */}
          <div>
            <h3 className="font-bold mb-4">Departments</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-background/70 hover:text-primary transition-colors text-sm">
                  Cardiology
                </Link>
              </li>
              <li>
                <Link href="#" className="text-background/70 hover:text-primary transition-colors text-sm">
                  Neurology
                </Link>
              </li>
              <li>
                <Link href="#" className="text-background/70 hover:text-primary transition-colors text-sm">
                  Orthopedics
                </Link>
              </li>
              <li>
                <Link href="#" className="text-background/70 hover:text-primary transition-colors text-sm">
                  Pediatrics
                </Link>
              </li>
              <li>
                <Link href="#" className="text-background/70 hover:text-primary transition-colors text-sm">
                  Emergency Care
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-bold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span className="text-background/70 text-sm">
                  Ward No. 10, Madanpur, Araria, Bihar - 854333
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-primary shrink-0" />
                <a href="tel:+919534311724" className="text-background/70 hover:text-primary transition-colors text-sm">
                  +91 9534311724
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-primary shrink-0" />
                <a href="mailto:papuyadav780@gmail.com" className="text-background/70 hover:text-primary transition-colors text-sm">
                  papuyadav780@gmail.com
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-primary shrink-0" />
                <a href="mailto:om71480@gmail.com" className="text-background/70 hover:text-primary transition-colors text-sm">
                  om71480@gmail.com
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Clock className="h-5 w-5 text-primary shrink-0" />
                <span className="text-background/70 text-sm">
                  24/7 Emergency Services
                </span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-background/10 mt-8 pt-8 text-center">
          <p className="text-background/50 text-sm">
            © {new Date().getFullYear()} HNC प्राकृतिक उपचार केंद्र। सर्वाधिकार सुरक्षित।
          </p>
        </div>
      </div>
    </footer>
  )
}
