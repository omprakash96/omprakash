import { 
  Salad, 
  Thermometer, 
  Shield, 
  Clock, 
  Zap, 
  Hand, 
  Leaf, 
  Activity, 
  FileText 
} from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const therapies = [
  {
    icon: Salad,
    title: "Dip Diet",
    titleHi: "डिप डाइट",
    description: "प्राकृतिक आहार पद्धति से शरीर को डिटॉक्स करें",
  },
  {
    icon: Thermometer,
    title: "3 Step Flu Diet",
    titleHi: "3 स्टेप फ्लू डाइट",
    description: "तीन चरणों में फ्लू और बुखार से राहत",
  },
  {
    icon: Shield,
    title: "GARD",
    titleHi: "गार्ड",
    description: "गैस्ट्रो एसिड रिफ्लक्स डिजीज का प्राकृतिक उपचार",
  },
  {
    icon: Clock,
    title: "Circadian Chart",
    titleHi: "सर्कैडियन चार्ट",
    description: "शरीर की जैविक घड़ी के अनुसार उपचार योजना",
  },
  {
    icon: Zap,
    title: "Zero Volt Therapy",
    titleHi: "जीरो वोल्ट थेरेपी",
    description: "विद्युत संतुलन से शरीर की ऊर्जा बहाल करें",
  },
  {
    icon: Hand,
    title: "Acupressure",
    titleHi: "एक्यूप्रेशर",
    description: "दबाव बिंदुओं से दर्द और रोगों का उपचार",
  },
  {
    icon: Leaf,
    title: "Ayurvedic Panchkarma",
    titleHi: "आयुर्वेदिक पंचकर्म",
    description: "पांच प्राकृतिक क्रियाओं से शरीर शुद्धि",
  },
  {
    icon: Activity,
    title: "Vaso-Stimulation Therapy",
    titleHi: "वासो-स्टिमुलेशन थेरेपी",
    description: "रक्त संचार को बढ़ाने की प्राकृतिक विधि",
  },
  {
    icon: FileText,
    title: "DAN Protocol",
    titleHi: "डैन प्रोटोकॉल",
    description: "विशेष उपचार प्रोटोकॉल से समग्र स्वास्थ्य",
  },
]

export function PatientCareSection() {
  return (
    <section className="py-16 md:py-24 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <span className="inline-block px-4 py-1.5 bg-primary/10 text-primary rounded-full text-sm font-medium mb-4">
            Patient Centric Care
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground text-balance">
            हमारी प्राकृतिक उपचार पद्धतियां
          </h2>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto text-pretty">
            HNC प्राकृतिक उपचार केंद्र में हम विभिन्न प्राकृतिक थेरेपी से आपके स्वास्थ्य को बेहतर बनाते हैं
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {therapies.map((therapy) => (
            <Card 
              key={therapy.title} 
              className="group hover:shadow-lg transition-all duration-300 hover:border-primary/50 bg-card"
            >
              <CardContent className="p-6">
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary group-hover:scale-110 transition-all duration-300">
                  <therapy.icon className="h-7 w-7 text-primary group-hover:text-primary-foreground transition-colors" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-1">{therapy.title}</h3>
                <p className="text-sm text-primary font-medium mb-2">{therapy.titleHi}</p>
                <p className="text-muted-foreground text-sm text-pretty">{therapy.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
